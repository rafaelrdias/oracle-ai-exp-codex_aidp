# Upload no OCI Resource Manager

Este pacote é específico para **Resource Manager > Stacks**, no Console OCI. Os arquivos `.tf` e `schema.yaml` estão na raiz do ZIP. Não exige Terraform/Python no computador, nem upload de PEM ou API key para criar a infraestrutura. O Resource Manager usa a sessão/autorização OCI do operador.

## Correção do erro de versão

O pacote anterior era para execução LOCAL com Terraform >= 1.7. O Resource Manager documenta suporte a **Terraform 1.5.x (CLI 1.5.7)**. Este pacote usa `required_version = "~> 1.5.0"` e autenticação própria do serviço. Além disso, um diretório de trabalho sem `.tf` pode impedir a identificação da configuração; este ZIP já possui os arquivos na raiz.

A mensagem “Invalid Terraform version: .” não informa sozinha se a causa foi a versão selecionada, a detecção do diretório ou ambas. Não é evidência de falha de IAM/AIDP.

## Criar a stack

1. Na própria trial ativada, abra **Developer Services > Resource Manager > Stacks > Create stack**.
2. Selecione **My configuration** / arquivo ZIP e envie `Terraform_Lab_Codex_AIDP_OCI_Resource_Manager.zip`.
3. Se aparecer **Working directory / Diretório de trabalho**, deixe na raiz (`.`). Não selecione a pasta `trial-aidp` do pacote antigo.
4. Em **Terraform version**, selecione **1.5.x** (a API pode mostrar `terraform_1.5.x`). Não deixe o campo vazio.
5. Crie a stack em um compartment já existente, como a raiz da trial. Ela não deve ficar dentro do compartment descartável que este Terraform vai criar/apagar.
6. Confira a tenancy preenchida automaticamente e escolha uma região assinada com AIDP e quota disponíveis. A região padrão deste pacote é Chicago (us-chicago-1), mas isso depende da trial.
7. Mantenha `lab-codex-aidp-rm` e workspace `lab-validacao`, ou ajuste o nome para outro exclusivo. Para o primeiro teste, deixe a opção de Lakehouse DESMARCADA.
8. Selecione **Run Plan**. Confira se o plano cria somente o ambiente esperado e, após revisar, execute **Apply**.
9. Nos Outputs, copie `aidp_instance_id`, `workspace_name` e `region` para continuar no Codex. No Console, confira que a instância está ACTIVE e abra o workspace.

Se a tentativa anterior falhou antes de criar a stack, use este ZIP na nova tentativa. Se a stack já existe, atualize a configuração da própria stack e a versão para 1.5.x, preservando o state; não crie uma segunda stack para gerenciar os mesmos recursos. Não migre um state criado com uma versão mais nova para 1.5.7 sem avaliar a compatibilidade.

## Escopo desta variante

Cria **compartment, policies do serviço, instância AIDP, workspace inicial e Lakehouse opcional**. As operações IAM são direcionadas à home region descoberta na tenancy.

**Não cria o Spark `labspark`, schema, volume, CSV, notebooks ou jobs.** A integração Spark do pacote local usava um script e caminhos locais; ela não foi transferida para a execução remota como se o Resource Manager pudesse acessar o seu computador. Essa parte segue pelo Codex/Workbench após o Apply. Para usar o plugin depois, o participante ainda configura sua API key local e os requisitos do plugin.

Opcionais de IA exigem Lakehouse 26ai. Com a opção marcada, o recurso é criado no mesmo state com 2 ECPUs e 1 TB de armazenamento, sem autoscaling, e senha digitada no campo protegido do formulário. Esse é o tamanho mínimo de armazenamento para este Lakehouse e consome créditos adicionais. O state pode conter a senha; mantenha acesso restrito à stack. O laboratório dos três notebooks não precisa dessa opção.

## Correção do armazenamento do Lakehouse

O erro `Autonomous AI Databases using Lakehouse workloads cannot allocate data storage in GBs` ocorreu porque a configuração anterior usava `data_storage_size_in_gb = 32`. O workload `LH` exige TB; agora o módulo usa somente `data_storage_size_in_tbs = 1`, conforme os [mínimos documentados pela Oracle](https://docs.oracle.com/en-us/iaas/autonomous-database-serverless/doc/autonomous-compute-models.html). Aumentar de 32 GB para 1 TB é uma mudança de capacidade, não apenas uma conversão de unidade.

Para retomar a tentativa que falhou: atualize a configuração da mesma stack com o ZIP corrigido, preserve seus parâmetros e state e execute um novo Plan. Confira o Lakehouse com 1 TB, a região `us-chicago-1` e eventuais alterações nos recursos já criados; depois execute Apply. Não é necessário executar Destroy para corrigir esse parâmetro. A validação local não substitui a aceitação da API na próxima execução OCI.

## Apagar

Antes de executar **Terraform actions > Destroy**, pare execuções e exporte o que quiser guardar. Recursos internos e buckets criados pelo AIDP não aparecem necessariamente como recursos individuais no state.

Para um ambiente já usado com dados, revise as opções de exclusão de arquivos/dados gerenciados no Console AIDP antes de remover a instância. Depois execute Destroy na stack para remover os recursos Terraform restantes. Se sobrarem buckets/log groups no compartment, a exclusão do compartment pode falhar: revise e remova somente os resíduos deste laboratório e repita Destroy. O pacote remoto não inclui o script local de limpeza automática. Não assuma que parar o Spark ou excluir a stack, sem Destroy, apaga a infraestrutura e encerra o consumo.

Não use o script `destroy.py` do pacote local contra esta stack: o state desta variante pertence ao Resource Manager.

## Validação e limites

Validação estática feita localmente com a mesma versão CLI 1.5.7, sem autenticar na OCI. Não houve Plan/Apply/Destroy real no Resource Manager. A validação não comprova elegibilidade da trial, aceitação de policies, quota ou capacidade regional.

Referências oficiais:

- [Versões suportadas pelo Resource Manager](https://docs.oracle.com/en-us/iaas/Content/ResourceManager/Reference/terraformversions.htm)
- [Autenticação e estrutura do ZIP](https://docs.oracle.com/en-us/iaas/Content/ResourceManager/Concepts/terraformconfigresourcemanager.htm)
- [Recurso AIDP no provider OCI](https://docs.oracle.com/en-us/iaas/tools/terraform-provider-oci/latest/docs/r/ai_data_platform_ai_data_platform.html)
